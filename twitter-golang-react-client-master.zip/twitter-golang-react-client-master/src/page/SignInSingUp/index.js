export { default } from "./SignInSingUp";
