export const API_HOST = "https://twittor-golang-react-server.herokuapp.com";
export const TOKEN = "token";
