export { ReactComponent as Location } from "../assets/svg/location.svg";
export { ReactComponent as Link } from "../assets/svg/link.svg";
export { ReactComponent as DateBirth } from "../assets/svg/date-birth.svg";
export { ReactComponent as Close } from "../assets/svg/close.svg";
export { ReactComponent as Camera } from "../assets/svg/camera.svg";
