export { default } from "./InfoUser";
