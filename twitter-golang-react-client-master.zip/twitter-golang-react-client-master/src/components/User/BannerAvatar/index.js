export { default } from "./BannerAvatar";
