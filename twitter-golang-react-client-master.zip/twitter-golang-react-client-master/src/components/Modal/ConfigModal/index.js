export { default } from "./ConfigModal";
