export { default } from "./BasicModal";
